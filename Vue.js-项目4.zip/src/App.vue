<template>
  <router-view></router-view>
</template>

<script>
import '@/assets/styles/reset.styl'
import 'utils/filter'

export default {
}
</script>
