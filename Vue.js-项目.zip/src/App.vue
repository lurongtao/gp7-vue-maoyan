<template>
  <Home></Home>
</template>

<script>
import '@/assets/styles/reset.styl'
import Home from './pages/Home'
import 'utils/filter'

export default {
  components: {
    Home
  }
}
</script>

<style lang="stylus">
</style>
