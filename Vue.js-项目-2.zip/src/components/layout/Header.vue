<template>
  <div>
    猫眼电影
  </div>
</template>

<script>
export default {
  components: {
    
  }
}
</script>


<style lang="stylus" scoped>
@import '~styles/variables.styl'
div
  height .5rem
  font-weight 100
  background $base-color
  color #fff
  font-size .18rem
  line-height .5rem
  text-align center
  z-index 999
</style>

